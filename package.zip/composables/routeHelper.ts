export default function () {
    let baseUrl = 'https://wiguna.cendikiawandigital.com/apitest/ranker/'
    baseUrl = 'http://localhost/project/apitest/ranker/'
    
    return {
        "usersUrl": baseUrl + "user/getUsers",
        "singleUserUrl": "bcd" 
    }
}