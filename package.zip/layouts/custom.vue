<template>
    <div>
        <h1>Custom Header</h1>
        <slot />
    </div>
</template>