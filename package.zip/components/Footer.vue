<template>
    <div>
        <h1 class="alert alert-success">Footer</h1>
    </div>
</template>